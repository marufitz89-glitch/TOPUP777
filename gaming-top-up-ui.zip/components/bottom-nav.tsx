"use client"

import { Home, Plus, FileText, Grid3x3, User } from "lucide-react"
import Link from "next/link"

const navItems = [
  { icon: Home, label: "হোম", id: "home", href: "/" },
  { icon: Plus, label: "টাকা যোগ করুন", id: "add", href: "/add-money" },
  { icon: FileText, label: "আমার অর্ডার", id: "orders", href: "/orders" },
  { icon: Grid3x3, label: "আমার কোড", id: "codes", href: "/codes" },
  { icon: User, label: "আমার একাউন্ট", id: "account", href: "/account" },
]

interface BottomNavProps {
  activeTab?: string
}

export function BottomNav({ activeTab = "home" }: BottomNavProps) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-card border-t border-border">
      <div className="flex items-center justify-around h-16 px-2">
        {navItems.map((item) => {
          const Icon = item.icon
          const isActive = activeTab === item.id

          return (
            <Link
              key={item.id}
              href={item.href}
              className={`flex flex-col items-center justify-center gap-1 px-3 py-2 rounded-lg transition-colors ${
                isActive ? "text-primary" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Icon className={`h-5 w-5 ${isActive ? "fill-primary" : ""}`} />
              <span className="text-xs font-medium">{item.label}</span>
            </Link>
          )
        })}
      </div>
    </nav>
  )
}
