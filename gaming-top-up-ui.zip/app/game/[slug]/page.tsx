import { Header } from "@/components/header"
import { GameOrderForm } from "@/components/game-order-form"
import { InstallBanner } from "@/components/install-banner"
import { BottomNav } from "@/components/bottom-nav"
import { Footer } from "@/components/footer"

export default function GameDetailPage({ params }: { params: { slug: string } }) {
  return (
    <div className="min-h-screen bg-background pb-20">
      <Header />
      <GameOrderForm slug={params.slug} />
      <Footer />
      <InstallBanner />
      <BottomNav activeTab="home" />

      <a
        href="https://t.me/marufitz"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-28 right-4 z-50 flex items-center gap-3 bg-gradient-to-r from-red-600 to-red-500 text-white px-6 py-3 rounded-full shadow-2xl hover:shadow-red-500/50 transition-all hover:scale-105 group"
      >
        <span className="font-semibold text-sm">সাহায্য লাগবে ?</span>
        <div className="bg-white/20 p-2 rounded-full group-hover:rotate-12 transition-transform">
          <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
            <path d="M20.5 3.5C18.25 1.25 15.25 0 12 0S5.75 1.25 3.5 3.5 0 8.75 0 12s1.25 6.25 3.5 8.5S8.75 24 12 24s6.25-1.25 8.5-3.5S24 15.25 24 12s-1.25-6.25-3.5-8.5zM12 22c-5.5 0-10-4.5-10-10S6.5 2 12 2s10 4.5 10 10-4.5 10-10 10zm1-17h-2v6h2V5zm0 8h-2v2h2v-2z" />
          </svg>
        </div>
      </a>

      <a
        href="tel:+8801234567890"
        className="fixed bottom-28 right-4 z-40 bg-gradient-to-br from-red-600 to-red-700 text-white p-4 rounded-full shadow-2xl hover:shadow-red-500/50 transition-all hover:scale-110"
        style={{ bottom: "180px" }}
      >
        <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
          <path d="M20.01 15.38c-1.23 0-2.42-.2-3.53-.56-.35-.12-.74-.03-1.01.24l-1.57 1.97c-2.83-1.35-5.48-3.9-6.89-6.83l1.95-1.66c.27-.28.35-.67.24-1.02-.37-1.11-.56-2.3-.56-3.53 0-.54-.45-.99-.99-.99H4.19C3.65 3 3 3.24 3 3.99 3 13.28 10.73 21 20.01 21c.71 0 .99-.63.99-1.18v-3.45c0-.54-.45-.99-.99-.99z" />
        </svg>
      </a>
    </div>
  )
}
