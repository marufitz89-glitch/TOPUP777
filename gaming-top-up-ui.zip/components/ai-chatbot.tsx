"use client"

import { useState, useRef, useEffect } from "react"
import { Bot, Send, X, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"

interface Message {
  id: string
  text: string
  sender: "user" | "ai"
  timestamp: Date
}

export function AIChatbot() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      text: "আসসালা'মুআলাইকুম সালাম! আমি BST Topup এর AI সহায়ক। আপনাকে কিভাবে সাহায্য করতে পারি?",
      sender: "ai",
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSend = async () => {
    if (!input.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      text: input,
      sender: "user",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsTyping(true)

    // Simulate AI response
    setTimeout(() => {
      const aiResponse = generateAIResponse(input.toLowerCase())
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: aiResponse,
        sender: "ai",
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, aiMessage])
      setIsTyping(false)
    }, 1000)
  }

  const generateAIResponse = (query: string): string => {
    // AI-powered response logic
    if (query.includes("টপআপ") || query.includes("topup") || query.includes("order")) {
      return "টপআপ করতে আপনার পছন্দের গেম সিলেক্ট করুন, তারপর আপনার গেম আইডি এবং পেমেন্ট মেথড দিন। AI স্বয়ংক্রিয়ভাবে আপনার অর্ডার প্রসেস করবে এবং ২-৫ মিনিটে ডায়মন্ড পৌঁছে যাবে!"
    } else if (query.includes("price") || query.includes("দাম") || query.includes("টাকা")) {
      return "আমাদের AI সিস্টেম সেরা দাম নিশ্চিত করে। প্রতিটি প্যাকেজের দাম গেম কার্ডে দেখানো আছে। বিশেষ অফারের জন্য হোমপেজ চেক করুন!"
    } else if (query.includes("payment") || query.includes("পেমেন্ট")) {
      return "আমরা Wallet Pay এবং Instant Pay (bKash, Nagad, Rocket) সাপোর্ট করি। AI স্বয়ংক্রিয়ভাবে আপনার পেমেন্ট ভেরিফাই করবে এবং তাৎক্ষণিক ডেলিভারি নিশ্চিত করবে।"
    } else if (query.includes("problem") || query.includes("সমস্যা") || query.includes("help")) {
      return "কোনো সমস্যা হলে আমাদের টেলিগ্রামে যোগাযোগ করুন: t.me/marufitz। AI সাপোর্ট টিম ২৪/৭ উপলব্ধ আছে।"
    } else if (query.includes("recommend") || query.includes("সুপারিশ")) {
      return "AI বিশ্লেষণ অনুযায়ী এই মাসে সবচেয়ে জনপ্রিয়: Free Fire Uid Topup (BD Server) এবং Weekly/Monthly পাস! বিশেষ ছাড় চলছে।"
    } else {
      return "আমি আপনার প্রশ্ন বুঝতে পারছি। আপনি চাইলে টপআপ, পেমেন্ট, অফার, বা সাপোর্ট সম্পর্কে জিজ্ঞাসা করতে পারেন। অথবা সরাসরি t.me/marufitz এ যোগাযোগ করুন।"
    }
  }

  return (
    <>
      {/* AI Chat Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-24 right-4 z-50 w-16 h-16 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-full shadow-2xl flex items-center justify-center hover:scale-110 transition-transform group"
        >
          <Bot className="w-7 h-7 text-white" />
          <Sparkles className="w-4 h-4 text-yellow-300 absolute -top-1 -right-1 animate-pulse" />
          <div className="absolute -top-1 -left-1 w-3 h-3 bg-green-500 rounded-full border-2 border-white animate-pulse" />
        </button>
      )}

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-24 right-4 z-50 w-[340px] h-[500px] bg-card border-2 border-indigo-500 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <Bot className="w-8 h-8 text-white" />
                <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-400 rounded-full border-2 border-white" />
              </div>
              <div>
                <h3 className="text-white font-bold flex items-center gap-1">
                  AI সহায়ক
                  <Sparkles className="w-4 h-4 text-yellow-300" />
                </h3>
                <p className="text-white/80 text-xs">স্বয়ংক্রিয় সেবা সক্রিয়</p>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-white/80 hover:text-white transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-background/50">
            {messages.map((message) => (
              <div key={message.id} className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}>
                <div
                  className={`max-w-[80%] rounded-2xl px-4 py-2 ${
                    message.sender === "user"
                      ? "bg-indigo-600 text-white"
                      : "bg-card border border-border text-foreground"
                  }`}
                >
                  <p className="text-sm">{message.text}</p>
                  <p
                    className={`text-xs mt-1 ${
                      message.sender === "user" ? "text-indigo-200" : "text-muted-foreground"
                    }`}
                  >
                    {message.timestamp.toLocaleTimeString("bn-BD", {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </p>
                </div>
              </div>
            ))}

            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-card border border-border rounded-2xl px-4 py-3">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 bg-indigo-600 rounded-full animate-bounce" />
                    <div className="w-2 h-2 bg-indigo-600 rounded-full animate-bounce delay-100" />
                    <div className="w-2 h-2 bg-indigo-600 rounded-full animate-bounce delay-200" />
                  </div>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 border-t border-border bg-card">
            <div className="flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleSend()}
                placeholder="আপনার প্রশ্ন লিখুন..."
                className="flex-1 px-4 py-2 rounded-full border border-border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
              <Button
                onClick={handleSend}
                disabled={!input.trim()}
                className="rounded-full w-10 h-10 p-0 bg-indigo-600 hover:bg-indigo-700"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-xs text-muted-foreground text-center mt-2">Powered by Premium AI • স্বয়ংক্রিয় উত্তর</p>
          </div>
        </div>
      )}
    </>
  )
}
