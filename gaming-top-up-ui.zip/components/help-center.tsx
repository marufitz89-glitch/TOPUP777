"use client"

import { MessageCircle, Phone, Mail, Send } from "lucide-react"
import { Button } from "@/components/ui/button"

export function HelpCenter() {
  const handleTelegramClick = () => {
    window.open("https://t.me/marufitz", "_blank")
  }

  return (
    <section className="px-4 py-6">
      <div className="mb-4">
        <h2 className="text-2xl font-bold text-foreground mb-2">সহায়তা কেন্দ্র</h2>
        <p className="text-muted-foreground text-sm">যেকোনো সমস্যার জন্য আমাদের সাথে যোগাযোগ করুন</p>
      </div>

      <div className="grid gap-4">
        {/* Telegram Support - Primary */}
        <div className="bg-gradient-to-br from-blue-600 to-blue-500 rounded-xl p-5 shadow-lg">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
              <Send className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">টেলিগ্রাম সাপোর্ট</h3>
              <p className="text-white/80 text-sm">দ্রুত সাহায্যের জন্য</p>
            </div>
          </div>
          <Button
            onClick={handleTelegramClick}
            className="w-full bg-white text-blue-600 hover:bg-white/90 font-semibold gap-2"
          >
            <Send className="w-4 h-4" />
            t.me/marufitz
          </Button>
        </div>

        {/* Other Support Options */}
        <div className="grid grid-cols-2 gap-3">
          <button className="bg-card hover:bg-accent border border-border rounded-xl p-4 text-left transition-colors">
            <MessageCircle className="w-6 h-6 text-indigo-500 mb-2" />
            <p className="font-semibold text-foreground text-sm">লাইভ চ্যাট</p>
            <p className="text-muted-foreground text-xs mt-1">২৪/৭ উপলব্ধ</p>
          </button>

          <button className="bg-card hover:bg-accent border border-border rounded-xl p-4 text-left transition-colors">
            <Phone className="w-6 h-6 text-green-500 mb-2" />
            <p className="font-semibold text-foreground text-sm">ফোন সাপোর্ট</p>
            <p className="text-muted-foreground text-xs mt-1">০৯:০০ - ২১:০০</p>
          </button>
        </div>

        {/* FAQ Section */}
        <div className="bg-card border border-border rounded-xl p-5">
          <div className="flex items-center gap-2 mb-3">
            <Mail className="w-5 h-5 text-indigo-500" />
            <h3 className="font-bold text-foreground">ইমেইল সাপোর্ট</h3>
          </div>
          <p className="text-muted-foreground text-sm mb-3">বিস্তারিত সমস্যার জন্য আমাদের ইমেইল করুন</p>
          <a href="mailto:support@bsttopup.com" className="text-indigo-500 text-sm font-semibold hover:underline">
            support@bsttopup.com
          </a>
        </div>
      </div>

      {/* Quick Help Links */}
      <div className="mt-5 p-4 bg-indigo-600/10 border border-indigo-600/20 rounded-xl">
        <h4 className="font-semibold text-foreground text-sm mb-2">সাধারণ প্রশ্ন</h4>
        <ul className="space-y-2">
          <li>
            <button className="text-indigo-500 text-sm hover:underline">কিভাবে টপআপ করবেন?</button>
          </li>
          <li>
            <button className="text-indigo-500 text-sm hover:underline">পেমেন্ট মেথড সম্পর্কে</button>
          </li>
          <li>
            <button className="text-indigo-500 text-sm hover:underline">রিফান্ড পলিসি</button>
          </li>
        </ul>
      </div>
    </section>
  )
}
