"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Sparkles, Zap, CheckCircle2, Clock, Rocket } from "lucide-react"

const gameData: Record<string, any> = {
  "uid-topup-bd-server": {
    name: "Free Fire Diamond TopUp",
    subtitle: "Uid Topup [BD SERVER]",
    packages: [
      { id: 1, name: "৫০ ডায়মন্ড", price: 50, diamonds: 50 },
      { id: 2, name: "১০০ ডায়মন্ড", price: 95, diamonds: 100 },
      { id: 3, name: "২১০ ডায়মন্ড", price: 190, diamonds: 210 },
      { id: 4, name: "৩১০ ডায়মন্ড", price: 285, diamonds: 310 },
      { id: 5, name: "৫২০ ডায়মন্ড", price: 475, diamonds: 520 },
      { id: 6, name: "১০৫০ ডায়মন্ড", price: 950, diamonds: 1050 },
    ],
  },
  "weekly-monthly": {
    name: "Weekly/Monthly Pass",
    subtitle: "উইকালী-মাসিক কৰয়া অফাৰ",
    packages: [
      { id: 1, name: "Weekly Pass", price: 150, type: "weekly" },
      { id: 2, name: "Monthly Pass", price: 550, type: "monthly" },
    ],
  },
}

export function GameOrderForm({ slug }: { slug: string }) {
  const game = gameData[slug] || gameData["uid-topup-bd-server"]
  const [selectedPackage, setSelectedPackage] = useState<any>(null)
  const [gameId, setGameId] = useState("")
  const [paymentMethod, setPaymentMethod] = useState<"wallet" | "instant">("wallet")
  const [isVerifying, setIsVerifying] = useState(false)
  const [isOrdering, setIsOrdering] = useState(false)
  const [orderProgress, setOrderProgress] = useState(0)
  const [orderCompleted, setOrderCompleted] = useState(false)

  const handleVerifyId = () => {
    setIsVerifying(true)
    setTimeout(() => {
      setIsVerifying(false)
      alert("✓ AI যাচাই সম্পন্ন! আপনার গেম আইডি সঠিক।")
    }, 2000)
  }

  const handleOrder = () => {
    if (!selectedPackage || !gameId) {
      alert("দয়া করে প্যাকেজ এবং গেম আইডি নির্বাচন করুন")
      return
    }

    setIsOrdering(true)
    setOrderProgress(0)

    const progressStages = [
      { progress: 20, message: "পেমেন্ট অটো-ভেরিফাই করা হচ্ছে..." },
      { progress: 40, message: "গেম সার্ভারের সাথে AI সংযোগ করছে..." },
      { progress: 60, message: "অর্ডার প্রসেস করা হচ্ছে..." },
      { progress: 80, message: "ডায়মন্ড ট্রান্সফার করা হচ্ছে..." },
      { progress: 100, message: "সম্পন্ন!" },
    ]

    let currentStage = 0
    const interval = setInterval(() => {
      if (currentStage < progressStages.length) {
        setOrderProgress(progressStages[currentStage].progress)
        currentStage++
      } else {
        clearInterval(interval)
        setIsOrdering(false)
        setOrderCompleted(true)

        setTimeout(() => {
          alert(
            `✓ অর্ডার সফলভাবে সম্পন্ন হয়েছে!\n${selectedPackage.diamonds} ডায়মন্ড আপনার আইডিতে পাঠানো হয়েছে।\n\nAI দ্বারা স্বয়ংক্রিয়ভাবে প্রসেস করা হয়েছে।`,
          )
          setOrderCompleted(false)
          setSelectedPackage(null)
          setGameId("")
        }, 2000)
      }
    }, 2000)
  }

  if (isOrdering || orderCompleted) {
    return (
      <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
        <Card className="p-8 max-w-md w-full bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-950 dark:to-purple-950 border-2 border-indigo-500">
          <div className="text-center">
            {orderCompleted ? (
              <>
                <div className="w-20 h-20 mx-auto mb-4 bg-green-600 rounded-full flex items-center justify-center animate-bounce">
                  <CheckCircle2 className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-green-600 mb-2">অর্ডার সফল!</h3>
                <p className="text-sm text-muted-foreground mb-4">AI দ্বারা {orderProgress / 10} সেকেন্ডে সম্পন্ন</p>
                <div className="bg-green-100 dark:bg-green-900 p-4 rounded-lg">
                  <p className="text-sm text-green-800 dark:text-green-200">
                    ✓ {selectedPackage?.diamonds} ডায়মন্ড সফলভাবে ডেলিভার করা হয়েছে
                  </p>
                </div>
              </>
            ) : (
              <>
                <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-full flex items-center justify-center">
                  <Rocket className="w-10 h-10 text-white animate-pulse" />
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-2">AI অর্ডার প্রসেস করছে</h3>
                <p className="text-sm text-muted-foreground mb-6">Premium AI সিস্টেম আপনার অর্ডার স্বয়ংক্রিয়ভাবে সম্পন্ন করছে</p>

                <div className="mb-6">
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3 mb-2">
                    <div
                      className="bg-gradient-to-r from-indigo-600 to-purple-600 h-3 rounded-full transition-all duration-500"
                      style={{ width: `${orderProgress}%` }}
                    />
                  </div>
                  <div className="flex items-center justify-center gap-2 text-sm text-indigo-600">
                    <Clock className="w-4 h-4 animate-spin" />
                    <span>{orderProgress}% সম্পন্ন</span>
                  </div>
                </div>

                <div className="bg-blue-100 dark:bg-blue-900 p-4 rounded-lg">
                  <p className="text-xs text-blue-800 dark:text-blue-200">
                    ⚡ AI স্বয়ংক্রিয়ভাবে পেমেন্ট চেক করছে, গেম সার্ভারে সংযোগ করছে এবং আপনার ডায়মন্ড ডেলিভার করছে। কোনো ম্যানুয়াল কাজ
                    প্রয়োজন নেই!
                  </p>
                </div>
              </>
            )}
          </div>
        </Card>
      </div>
    )
  }

  return (
    <div className="px-4 py-6 max-w-2xl mx-auto">
      <div className="mb-4 p-4 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-xl text-white">
        <div className="flex items-center gap-2 mb-2">
          <Sparkles className="w-5 h-5 text-yellow-300" />
          <h3 className="font-bold">Premium AI স্বয়ংক্রিয় অর্ডার সিস্টেম</h3>
        </div>
        <p className="text-sm text-white/90">
          অর্ডার করার সাথে সাথে AI পেমেন্ট চেক করবে এবং ১০ সেকেন্ডে অটোমেটিক ডেলিভারি দিবে
        </p>
      </div>

      <Card className="mb-4 p-6 bg-card border-2 border-indigo-500/30">
        <div className="flex items-center gap-3 mb-4">
          <div className="bg-indigo-600 text-white rounded-full w-8 h-8 flex items-center justify-center font-bold">
            1
          </div>
          <h2 className="text-xl font-bold text-foreground">Select Package</h2>
          <div className="ml-auto bg-yellow-400 text-gray-900 text-xs font-bold px-2 py-1 rounded-full flex items-center gap-1">
            <Zap className="w-3 h-3" />
            AI Smart
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {game.packages.map((pkg: any) => (
            <button
              key={pkg.id}
              onClick={() => setSelectedPackage(pkg)}
              className={`p-4 rounded-xl border-2 transition-all ${
                selectedPackage?.id === pkg.id
                  ? "border-indigo-600 bg-indigo-50 dark:bg-indigo-950"
                  : "border-gray-300 hover:border-indigo-400"
              }`}
            >
              <div className="font-bold text-foreground">{pkg.name}</div>
              <div className="text-sm text-muted-foreground">৳ {pkg.price}</div>
            </button>
          ))}
        </div>

        {selectedPackage && (
          <div className="mt-4 p-4 bg-indigo-50 dark:bg-indigo-950 rounded-lg">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
              </svg>
              <span>প্রোডাক্ট নির্বাচিত হয়েছে । মূল্যঃ ৳ {selectedPackage.price}</span>
              <Sparkles className="w-4 h-4 text-indigo-600 ml-auto" />
            </div>
          </div>
        )}
      </Card>

      <a href="#" className="flex items-center gap-2 text-red-600 font-semibold mb-4 hover:underline">
        <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
          <path d="M19 19H5V5h7V3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2v-7h-2v7zM14 3v2h3.59l-9.83 9.83 1.41 1.41L19 6.41V10h2V3h-7z" />
        </svg>
        কিভাবে অর্ডার করবেন ?
      </a>

      <Card className="mb-4 p-6 bg-card border-2 border-indigo-500/30">
        <div className="flex items-center gap-3 mb-4">
          <div className="bg-indigo-600 text-white rounded-full w-8 h-8 flex items-center justify-center font-bold">
            2
          </div>
          <h2 className="text-xl font-bold text-foreground">Account Info</h2>
          <div className="ml-auto bg-green-500 text-white text-xs font-bold px-2 py-1 rounded-full flex items-center gap-1">
            <Sparkles className="w-3 h-3" />
            AI যাচাই
          </div>
        </div>

        <label className="block text-sm font-medium text-foreground mb-2">এখানে গেমের আইডিটি কোড দিন</label>
        <Input
          type="text"
          placeholder="এখানে গেমের আইডিটি কোড দিন"
          value={gameId}
          onChange={(e) => setGameId(e.target.value)}
          className="mb-4 h-12 border-2 border-indigo-500/30 focus:border-indigo-600"
        />

        <Button
          onClick={handleVerifyId}
          disabled={!gameId || isVerifying}
          className="w-full h-12 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold flex items-center justify-center gap-2"
        >
          {isVerifying ? (
            <>
              <Sparkles className="w-4 h-4 animate-spin" />
              AI যাচাই করছে...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              AI দিয়ে গেম আইডি যাচাই করুন
            </>
          )}
        </Button>
      </Card>

      <Card className="mb-4 p-6 bg-card border-2 border-indigo-500/30">
        <div className="flex items-center gap-3 mb-4">
          <div className="bg-indigo-600 text-white rounded-full w-8 h-8 flex items-center justify-center font-bold">
            3
          </div>
          <h2 className="text-xl font-bold text-foreground">Select one option</h2>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-4">
          <button
            onClick={() => setPaymentMethod("wallet")}
            className={`relative p-6 rounded-xl border-2 transition-all ${
              paymentMethod === "wallet"
                ? "border-indigo-600 bg-indigo-50 dark:bg-indigo-950"
                : "border-gray-300 hover:border-indigo-400"
            }`}
          >
            {paymentMethod === "wallet" && (
              <div className="absolute top-0 left-0 w-0 h-0 border-l-[40px] border-l-red-600 border-b-[40px] border-b-transparent">
                <svg
                  className="absolute -top-[35px] -left-[35px] h-5 w-5 text-white"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" />
                </svg>
              </div>
            )}
            <img src="/bst-topup-wallet.jpg" alt="Wallet Pay" className="h-16 mx-auto mb-2" />
            <div className="text-sm font-semibold text-gray-600">Wallet Pay</div>
          </button>

          <button
            onClick={() => setPaymentMethod("instant")}
            className={`relative p-6 rounded-xl border-2 transition-all ${
              paymentMethod === "instant"
                ? "border-indigo-600 bg-indigo-50 dark:bg-indigo-950"
                : "border-gray-300 hover:border-indigo-400"
            }`}
          >
            {paymentMethod === "instant" && (
              <div className="absolute top-0 left-0 w-0 h-0 border-l-[40px] border-l-red-600 border-b-[40px] border-b-transparent">
                <svg
                  className="absolute -top-[35px] -left-[35px] h-5 w-5 text-white"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" />
                </svg>
              </div>
            )}
            <div className="flex justify-center gap-2 mb-2">
              <img src="/bkash.jpg" alt="bKash" className="h-10" />
              <img src="/nagad.jpg" alt="Nagad" className="h-10" />
              <img src="/rocket.jpg" alt="Rocket" className="h-10" />
            </div>
            <div className="text-sm font-semibold text-gray-600">Instant Pay</div>
          </button>
        </div>

        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
          <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z" />
          </svg>
          <span>আপনার অ্যাকাউন্টটি ব্যালেন্স</span>
          <span className="text-indigo-600 font-bold">৳ 0.00</span>
          <button className="ml-auto">
            <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
              <path d="M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z" />
            </svg>
          </button>
        </div>

        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z" />
          </svg>
          <span>শোভাই কিনতে আপনার প্রয়োজন</span>
        </div>
      </Card>

      <Button
        onClick={handleOrder}
        disabled={!selectedPackage || !gameId}
        className="w-full h-14 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-bold text-lg mb-6 flex items-center justify-center gap-2 disabled:opacity-50"
      >
        <Zap className="w-5 h-5" />
        AI দিয়ে তাৎক্ষণিক অর্ডার করুন
      </Button>

      <div className="mb-6 p-4 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950 dark:to-emerald-950 border-2 border-green-500/30 rounded-xl">
        <div className="flex items-center gap-2 mb-2">
          <Sparkles className="w-5 h-5 text-green-600" />
          <h3 className="font-bold text-foreground">AI স্বয়ংক্রিয় গ্যারান্টি</h3>
        </div>
        <ul className="text-sm text-muted-foreground space-y-1">
          <li>✓ ১০ সেকেন্ডে AI দ্বারা স্বয়ংক্রিয় প্রসেসিং</li>
          <li>✓ ২৪/৭ Premium AI সাপোর্ট সক্রিয়</li>
          <li>✓ তাৎক্ষণিক ডেলিভারি নিশ্চিত</li>
          <li>✓ স্মার্ট পেমেন্ট ভেরিফিকেশন</li>
        </ul>
      </div>

      <Card className="p-6 bg-card border-2 border-indigo-500/30 mb-6">
        <h3 className="text-xl font-bold text-foreground mb-4">Rules & Conditions</h3>
        <div className="text-sm text-foreground leading-relaxed space-y-3">
          <p>শুধুমাত্র Bangladesh সার্ভারে ID Code দিয়ে টপ আপ হবে।</p>
          <p>Player ID Code ভুল দিলে Diamond না পেলে BST TOPUP কর্তৃপক্ষ দায়ী নয় ।</p>
          <p>Order কনফার্ম হওয়ার পরেও আইডিতে ডাইমন্ড না পেলে চেক করার জন্য ID Pass দিতে হবে।</p>
          <p>
            অর্ডার Cancel হলে কি কারণে তা Cancel হয়েছে তা অর্ডার হিস্টারিতে দেওয়া থাকে অনুগ্রহ পূর্বক দেখে পরায় সঠিক তথ্য দিয়ে অর্ডার
            করবেন।
          </p>
        </div>
      </Card>
    </div>
  )
}
