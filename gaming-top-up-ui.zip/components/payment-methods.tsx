import { Card } from "@/components/ui/card"

export function PaymentMethods() {
  const methods = [
    { name: "bKash", icon: "💳", color: "from-pink-600 to-pink-700" },
    { name: "Nagad", icon: "📱", color: "from-orange-600 to-orange-700" },
    { name: "Rocket", icon: "🚀", color: "from-purple-600 to-purple-700" },
    { name: "Bank", icon: "🏦", color: "from-blue-600 to-blue-700" },
  ]

  return (
    <section className="px-4 mt-8">
      <h2 className="text-xl font-bold text-foreground mb-4">পেমেন্ট মেথড</h2>
      <div className="grid grid-cols-4 gap-3">
        {methods.map((method, index) => (
          <Card
            key={index}
            className="group cursor-pointer border-border bg-card hover:border-primary transition-all overflow-hidden"
          >
            <div className={`bg-gradient-to-br ${method.color} p-4 flex flex-col items-center justify-center gap-2`}>
              <span className="text-2xl">{method.icon}</span>
              <span className="text-xs font-semibold text-white">{method.name}</span>
            </div>
          </Card>
        ))}
      </div>
    </section>
  )
}
