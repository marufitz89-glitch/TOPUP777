"use client"

import { Menu, Share2, Bookmark, MoreVertical } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import Link from "next/link"

export function Header() {
  const isAuthenticated = false

  return (
    <header className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80 border-b border-border">
      <div className="flex items-center justify-between px-4 py-3">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" className="text-foreground">
            <Menu className="h-5 w-5" />
          </Button>
          <div className="flex flex-col">
            <span className="text-sm font-semibold text-foreground">BST Topup BD</span>
            <span className="text-xs text-muted-foreground">bsttopup.com</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" className="text-foreground">
            <Share2 className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" className="text-foreground">
            <Bookmark className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" className="text-foreground">
            <MoreVertical className="h-5 w-5" />
          </Button>
        </div>
      </div>

      <div className="flex items-center justify-between px-4 py-4 border-t border-border">
        <div className="flex items-center gap-3">
          <div className="h-12 w-12 rounded-full bg-primary flex items-center justify-center">
            <span className="text-lg font-bold text-primary-foreground">BST</span>
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground">BST Topup</h1>
            <p className="text-xs text-muted-foreground">UPcoming soon BD</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-full px-6 gap-2">
            <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"
              />
            </svg>
            <span className="font-semibold">০৳</span>
          </Button>

          <Link href={isAuthenticated ? "/account" : "/auth"}>
            <Avatar className="h-12 w-12 ring-2 ring-primary cursor-pointer hover:ring-indigo-500 transition-all">
              <AvatarImage src="/gaming-avatar.jpg" alt="User" />
              <AvatarFallback className="bg-accent text-accent-foreground">U</AvatarFallback>
            </Avatar>
          </Link>
        </div>
      </div>
    </header>
  )
}
