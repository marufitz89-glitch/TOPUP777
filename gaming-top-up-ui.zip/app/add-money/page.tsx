import { Header } from "@/components/header"
import { BottomNav } from "@/components/bottom-nav"
import { InstallBanner } from "@/components/install-banner"
import { AddMoneyForm } from "@/components/add-money-form"

export default function AddMoneyPage() {
  return (
    <div className="min-h-screen bg-background pb-24">
      <Header />

      <main className="px-4 py-6">
        <h1 className="text-2xl font-bold text-foreground mb-6">Add Money</h1>

        <AddMoneyForm />

        <div className="mt-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="h-10 w-10 rounded-lg bg-accent/50 flex items-center justify-center">
              <svg className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                />
              </svg>
            </div>
            <h2 className="text-lg font-semibold text-foreground">How to add money</h2>
          </div>

          <div className="bg-card border border-border rounded-lg p-8 flex items-center justify-center min-h-[300px]">
            <div className="text-center">
              <svg
                className="h-24 w-24 mx-auto text-muted-foreground/40"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={1.5}
                  d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                />
              </svg>
              <p className="text-sm text-muted-foreground mt-4">No instructions available</p>
            </div>
          </div>
        </div>
      </main>

      <InstallBanner />
      <BottomNav activeTab="add" />
    </div>
  )
}
