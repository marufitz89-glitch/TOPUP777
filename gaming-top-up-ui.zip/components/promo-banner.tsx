"use client"

import { Card } from "@/components/ui/card"
import { useState } from "react"

const promoBanners = [
  {
    title: "Website Development",
    description: "Our AI-powered website will be under development this week. Enjoy faster number verification!",
    bg: "bg-gradient-to-br from-purple-600 via-purple-700 to-indigo-800",
  },
  {
    title: "Special Offers",
    description: "Get amazing discounts on all game top-ups this month!",
    bg: "bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-700",
  },
  {
    title: "Fast Delivery",
    description: "Experience lightning-fast top-up delivery in seconds!",
    bg: "bg-gradient-to-br from-blue-600 via-indigo-700 to-purple-800",
  },
]

export function PromoBanner() {
  const [currentSlide, setCurrentSlide] = useState(0)

  return (
    <div className="px-4 mt-4">
      <div className="relative overflow-hidden rounded-xl">
        {promoBanners.map((banner, index) => (
          <Card
            key={index}
            className={`${banner.bg} border-0 p-8 transition-all duration-300 ${
              index === currentSlide ? "block" : "hidden"
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex-1 space-y-3">
                <div className="inline-block bg-white/20 backdrop-blur-sm rounded-full px-4 py-1">
                  <span className="text-xs font-semibold text-white uppercase tracking-wide">Notice</span>
                </div>
                <h2 className="text-2xl font-bold text-white">{banner.title}</h2>
                <p className="text-sm text-white/90 leading-relaxed max-w-md">{banner.description}</p>
                <div className="pt-2">
                  <span className="text-xs text-white/80 font-medium">Team BST Topup</span>
                </div>
              </div>

              <div className="hidden sm:block">
                <div className="relative w-40 h-40 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 p-4">
                  <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent rounded-2xl" />
                </div>
              </div>
            </div>
          </Card>
        ))}

        <div className="flex justify-center gap-2 mt-4">
          {promoBanners.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`h-1.5 rounded-full transition-all ${
                index === currentSlide ? "w-8 bg-primary" : "w-1.5 bg-muted"
              }`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      </div>
    </div>
  )
}
