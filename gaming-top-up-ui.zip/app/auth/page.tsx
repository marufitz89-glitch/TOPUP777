"use client"
import { Header } from "@/components/header"
import { AuthForm } from "@/components/auth-form"
import { BottomNav } from "@/components/bottom-nav"
import { Footer } from "@/components/footer"

export default function AuthPage() {
  return (
    <div className="min-h-screen bg-background pb-20">
      <Header />
      <AuthForm />
      <Footer />
      <BottomNav />
    </div>
  )
}
