"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Mail, Lock, User, Eye, EyeOff } from "lucide-react"
import { useRouter } from "next/navigation"

export function AuthForm() {
  const [isLogin, setIsLogin] = useState(true)
  const [showPassword, setShowPassword] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    phone: "",
  })
  const router = useRouter()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("[v0] Auth form submitted:", formData)
    // For demo, redirect to account page
    router.push("/account")
  }

  const handleGoogleAuth = () => {
    console.log("[v0] Google auth initiated")
    // For demo, redirect to account page
    router.push("/account")
  }

  return (
    <div className="px-4 py-8 max-w-md mx-auto">
      {/* Auth Header */}
      <div className="text-center mb-8">
        <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
          <span className="text-3xl font-bold text-white">BST</span>
        </div>
        <h1 className="text-2xl font-bold text-foreground mb-2">{isLogin ? "লগইন করুন" : "একাউন্ট তৈরি করুন"}</h1>
        <p className="text-sm text-muted-foreground">{isLogin ? "আপনার একাউন্টে লগইন করুন" : "নতুন একাউন্ট তৈরি করুন"}</p>
      </div>

      {/* Auth Form */}
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Name Field (Sign Up Only) */}
        {!isLogin && (
          <div className="space-y-2">
            <Label htmlFor="name" className="text-foreground">
              নাম
            </Label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                id="name"
                type="text"
                placeholder="আপনার নাম লিখুন"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="pl-10 bg-background border-border text-foreground"
                required={!isLogin}
              />
            </div>
          </div>
        )}

        {/* Email Field */}
        <div className="space-y-2">
          <Label htmlFor="email" className="text-foreground">
            ইমেইল
          </Label>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              id="email"
              type="email"
              placeholder="আপনার ইমেইল লিখুন"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="pl-10 bg-background border-border text-foreground"
              required
            />
          </div>
        </div>

        {/* Phone Field (Sign Up Only) */}
        {!isLogin && (
          <div className="space-y-2">
            <Label htmlFor="phone" className="text-foreground">
              ফোন নম্বর
            </Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">+880</span>
              <Input
                id="phone"
                type="tel"
                placeholder="১৭XXXXXXXXX"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="pl-16 bg-background border-border text-foreground"
                required={!isLogin}
              />
            </div>
          </div>
        )}

        {/* Password Field */}
        <div className="space-y-2">
          <Label htmlFor="password" className="text-foreground">
            পাসওয়ার্ড
          </Label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              id="password"
              type={showPassword ? "text" : "password"}
              placeholder="আপনার পাসওয়ার্ড লিখুন"
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              className="pl-10 pr-10 bg-background border-border text-foreground"
              required
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {/* Forgot Password (Login Only) */}
        {isLogin && (
          <div className="text-right">
            <button type="button" className="text-sm text-indigo-500 hover:text-indigo-600">
              পাসওয়ার্ড ভুলে গেছেন?
            </button>
          </div>
        )}

        {/* Submit Button */}
        <Button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white h-12 text-base">
          {isLogin ? "লগইন করুন" : "একাউন্ট তৈরি করুন"}
        </Button>
      </form>

      {/* Divider */}
      <div className="relative my-6">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-border"></div>
        </div>
        <div className="relative flex justify-center text-sm">
          <span className="px-4 bg-background text-muted-foreground">অথবা</span>
        </div>
      </div>

      {/* Google Sign In */}
      <Button
        type="button"
        onClick={handleGoogleAuth}
        variant="outline"
        className="w-full border-2 border-border hover:bg-accent h-12 text-base gap-3 bg-transparent"
      >
        <svg className="h-5 w-5" viewBox="0 0 24 24">
          <path
            fill="#4285F4"
            d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
          />
          <path
            fill="#34A853"
            d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
          />
          <path
            fill="#FBBC05"
            d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
          />
          <path
            fill="#EA4335"
            d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
          />
        </svg>
        <span className="text-foreground">Continue with Google</span>
      </Button>

      {/* Toggle Auth Mode */}
      <div className="mt-6 text-center">
        <p className="text-sm text-muted-foreground">
          {isLogin ? "নতুন ইউজার?" : "একাউন্ট আছে?"}{" "}
          <button
            type="button"
            onClick={() => setIsLogin(!isLogin)}
            className="text-indigo-500 hover:text-indigo-600 font-semibold"
          >
            {isLogin ? "একাউন্ট তৈরি করুন" : "লগইন করুন"}
          </button>
        </p>
      </div>

      {/* Terms & Privacy */}
      {!isLogin && (
        <p className="mt-6 text-xs text-center text-muted-foreground">
          একাউন্ট তৈরি করে আপনি আমাদের{" "}
          <button type="button" className="text-indigo-500 hover:underline">
            শর্তাবলী
          </button>{" "}
          এবং{" "}
          <button type="button" className="text-indigo-500 hover:underline">
            গোপনীয়তা নীতি
          </button>{" "}
          সম্মত হচ্ছেন।
        </p>
      )}
    </div>
  )
}
