import { Header } from "@/components/header"
import { AccountProfile } from "@/components/account-profile"
import { InstallBanner } from "@/components/install-banner"
import { BottomNav } from "@/components/bottom-nav"
import { Footer } from "@/components/footer"

export default function AccountPage() {
  return (
    <div className="min-h-screen bg-background pb-20">
      <Header />
      <AccountProfile />
      <InstallBanner />
      <Footer />
      <BottomNav activeTab="account" />
    </div>
  )
}
