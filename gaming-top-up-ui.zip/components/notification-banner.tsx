"use client"

import { X, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useState } from "react"

export function NotificationBanner() {
  const [isVisible, setIsVisible] = useState(true)

  if (!isVisible) return null

  return (
    <div className="relative bg-primary px-4 py-4 mx-4 mt-4 rounded-lg">
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <h3 className="text-base font-bold text-primary-foreground">Notice:</h3>
            <span className="bg-yellow-400 text-gray-900 text-xs font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
              <Sparkles className="w-3 h-3" />
              AI Powered
            </span>
          </div>
          <p className="text-sm text-primary-foreground/90 leading-relaxed">
            BST TOPUP এ আপনাকে স্বাগতম, এখানে মাত্র ১০ সেকেন্ডের মধ্যে <strong>Premium AI Bot</strong> দ্বারা স্বয়ংক্রিয়ভাবে টপআপ
            কমপ্লিট করা হয়। আমাদের AI সিস্টেম ২৪ ঘন্টা সক্রিয় থাকে এবং তাৎক্ষণিক ডেলিভারি নিশ্চিত করে।
          </p>
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="shrink-0 h-8 w-8 text-primary-foreground hover:bg-primary-foreground/20 rounded-full"
          onClick={() => setIsVisible(false)}
        >
          <X className="h-5 w-5" />
        </Button>
      </div>
    </div>
  )
}
