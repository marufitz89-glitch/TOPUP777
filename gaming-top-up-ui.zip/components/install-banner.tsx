"use client"

import { Download, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useState, useEffect } from "react"

export function InstallBanner() {
  const [isVisible, setIsVisible] = useState(true)
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null)

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault()
      setDeferredPrompt(e)
    }

    window.addEventListener("beforeinstallprompt", handler)

    return () => window.removeEventListener("beforeinstallprompt", handler)
  }, [])

  const handleInstall = async () => {
    if (!deferredPrompt) {
      // If PWA prompt not available, trigger APK download
      const apkUrl = "/bst-topup.apk" // APK file should be in public folder
      const link = document.createElement("a")
      link.href = apkUrl
      link.download = "BST-Topup.apk"
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)

      // Show installation instructions
      alert("APK ডাউনলোড হচ্ছে! ডাউনলোড সম্পূর্ণ হলে ফাইলটি খুলুন এবং ইনস্টল করুন।")
      return
    }

    // Show PWA install prompt
    deferredPrompt.prompt()
    const { outcome } = await deferredPrompt.userChoice

    if (outcome === "accepted") {
      console.log("[v0] PWA installed successfully")
      setIsVisible(false)
    }

    setDeferredPrompt(null)
  }

  if (!isVisible) return null

  return (
    <div className="fixed bottom-20 left-0 right-0 z-40 px-4">
      <div className="bg-indigo-600 rounded-2xl p-4 flex items-center justify-between shadow-2xl">
        <div className="flex items-center gap-3">
          <div className="bg-white/20 rounded-full p-2">
            <Download className="h-6 w-6 text-white" />
          </div>
          <span className="text-lg font-bold text-white">Install App</span>
        </div>

        <div className="flex items-center gap-2">
          <Button
            onClick={handleInstall}
            className="bg-white text-indigo-600 hover:bg-white/90 font-bold px-6 rounded-xl"
          >
            Install
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="text-white hover:bg-white/20 rounded-full"
            onClick={() => setIsVisible(false)}
          >
            <X className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </div>
  )
}
