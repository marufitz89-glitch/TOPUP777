import { Header } from "@/components/header"
import { BottomNav } from "@/components/bottom-nav"
import { InstallBanner } from "@/components/install-banner"
import { Button } from "@/components/ui/button"
import { Grid3x3 } from "lucide-react"
import Link from "next/link"

export default function CodesPage() {
  return (
    <div className="min-h-screen bg-background pb-20">
      <Header />

      <main className="p-4">
        <div className="bg-card rounded-lg border border-border p-6">
          <div className="flex items-center gap-3 mb-8 pb-4 border-b border-border">
            <Grid3x3 className="h-6 w-6 text-foreground" />
            <h1 className="text-2xl font-bold text-foreground">My Codes</h1>
          </div>

          <div className="flex flex-col items-center justify-center py-12">
            <p className="text-xl font-bold text-foreground mb-6">No code data found !</p>
            <Link href="/">
              <Button className="bg-red-500 hover:bg-red-600 text-white px-8 py-3 rounded-md font-semibold">
                ORDER NOW
              </Button>
            </Link>
          </div>
        </div>
      </main>

      <InstallBanner />
      <BottomNav activeTab="codes" />
    </div>
  )
}
