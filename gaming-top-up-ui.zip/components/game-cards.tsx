import { Card } from "@/components/ui/card"
import Link from "next/link"

const games = [
  {
    name: "Uid Topup [BD SERVER]",
    subtitle: "গেমার দেওয়া তৎক্ষণাৎ",
    image: "/game-free-fire-topup.jpg",
    badge: "BST TOPUP",
    slug: "uid-topup-bd-server", // Added slug for routing
  },
  {
    name: "Weekly/Monthly",
    subtitle: "উইকালী-মাসিক কৰয়া অফাৰ",
    image: "/game-weekly-monthly.jpg",
    badge: "BST TOPUP",
    slug: "weekly-monthly", // Added slug for routing
  },
  {
    name: "WEEKLY LITE",
    subtitle: "সাপ্তাহিক লাইট",
    image: "/game-weekly-lite.jpg",
    badge: "BST TOPUP",
  },
  {
    name: "Evo Access [Uid]",
    subtitle: "ভারত দেওয়া ইভো অক্সেস",
    image: "/game-evo-access.jpg",
    badge: "BST TOPUP",
  },
  {
    name: "Level UP PASS",
    subtitle: "লেভেল আপ পাস",
    image: "/game-level-up.jpg",
    badge: "BST TOPUP",
  },
  {
    name: "Free Fire Uid Topup [Indonesia]",
    subtitle: "ইন্দোনেশিয়ান টপআপ",
    image: "/game-indonesia.jpg",
    badge: "BST TOPUP",
  },
  {
    name: "UNIPIN",
    subtitle: "ইউনিপিন ভাউচার",
    image: "/game-unipin.jpg",
    badge: "BST TOPUP",
  },
]

export function GameCards() {
  return (
    <section className="px-4 pb-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-center text-foreground">ফ্রি ফায়ার টপ-আ্যাপ</h2>
      </div>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
        {games.map((game, index) => (
          <Link key={index} href={`/game/${game.slug}`}>
            <Card className="group relative overflow-hidden rounded-2xl border-2 border-indigo-500/30 bg-card hover:border-indigo-500 transition-all cursor-pointer shadow-lg hover:shadow-indigo-500/20">
              <div className="relative">
                <div className="aspect-[4/5] relative overflow-hidden rounded-t-xl">
                  <img
                    src={game.image || `/placeholder.svg?height=400&width=320&query=${game.name}`}
                    alt={game.name}
                    className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-2 left-2 bg-red-600 rounded-full p-1.5">
                    <svg className="h-4 w-4 text-white" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2L2 7v10c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-10-5z" />
                    </svg>
                  </div>
                </div>

                <div className="bg-white p-3 rounded-b-xl">
                  <h3 className="font-bold text-sm text-gray-900 text-center line-clamp-2 min-h-[2.5rem]">
                    {game.name}
                  </h3>
                </div>
              </div>
            </Card>
          </Link>
        ))}
      </div>
    </section>
  )
}
