import { Header } from "@/components/header"
import { NotificationBanner } from "@/components/notification-banner"
import { ActionButtons } from "@/components/action-buttons"
import { ImageSlider } from "@/components/image-slider"
import { AIRecommendations } from "@/components/ai-recommendations"
import { GameCards } from "@/components/game-cards"
import { AIChatbot } from "@/components/ai-chatbot"
import { InstallBanner } from "@/components/install-banner"
import { BottomNav } from "@/components/bottom-nav"
import { Footer } from "@/components/footer"

export default function HomePage() {
  const sliderImages = [
    "/images/screenshot-20251224-104256.png",
    "/gaming-promotional-banner-free-fire.jpg",
    "/pubg-mobile-top-up-offer.jpg",
    "/mobile-legends-special-deal.jpg",
  ]

  return (
    <div className="min-h-screen bg-background pb-20">
      <Header />
      <NotificationBanner />
      <ActionButtons />
      <ImageSlider images={sliderImages} autoPlayInterval={5000} />
      <AIRecommendations />
      <GameCards />
      <InstallBanner />
      <Footer />
      <BottomNav activeTab="home" />
      <AIChatbot />
    </div>
  )
}
