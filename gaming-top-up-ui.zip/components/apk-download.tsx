"use client"

import { Download, Smartphone } from "lucide-react"
import { Button } from "@/components/ui/button"

export function ApkDownload() {
  const handleDownload = () => {
    console.log("[v0] Initiating APK download...")

    // Direct download link - replace with your actual APK URL
    const apkUrl = "/bst-topup.apk" // This should be in the public folder

    // Create a temporary anchor element to trigger download
    const link = document.createElement("a")
    link.href = apkUrl
    link.download = "BST-Topup.apk"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)

    // Show success message
    alert("APK ডাউনলোড শুরু হচ্ছে! ডাউনলোড সম্পূর্ণ হলে ফাইলটি খুলে ইনস্টল করুন।")
  }

  return (
    <section className="px-4 py-6">
      <div className="bg-gradient-to-br from-indigo-600 to-purple-600 rounded-2xl p-6 shadow-lg">
        <div className="flex items-start gap-4">
          <div className="flex-shrink-0">
            <div className="w-14 h-14 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
              <Smartphone className="w-7 h-7 text-white" />
            </div>
          </div>

          <div className="flex-1">
            <h3 className="text-xl font-bold text-white mb-2">BST TOPUP অ্যাপ ডাউনলোড করুন</h3>
            <p className="text-white/90 text-sm mb-4">
              দ্রুত টপআপ এবং বিশেষ অফার পেতে আমাদের অফিসিয়াল অ্যান্ড্রয়েড অ্যাপ ইনস্টল করুন
            </p>

            <Button
              onClick={handleDownload}
              className="bg-white text-indigo-600 hover:bg-white/90 font-semibold gap-2 shadow-lg"
            >
              <Download className="w-4 h-4" />
              APK ডাউনলোড করুন
            </Button>

            <p className="text-white/70 text-xs mt-3">সংস্করণ: 2.1.0 | আকার: 12.5 MB</p>
          </div>
        </div>
      </div>
    </section>
  )
}
