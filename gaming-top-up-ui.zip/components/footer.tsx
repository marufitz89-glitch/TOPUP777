export function Footer() {
  return (
    <footer className="mt-12 mb-4 px-4">
      <div className="border-t border-border pt-6 pb-2">
        <div className="text-center space-y-1">
          <p className="text-xs text-muted-foreground">
            Full control by a <span className="text-primary font-semibold">premium AI</span>
          </p>
          <p className="text-xs text-muted-foreground">All rights reserved</p>
          <p className="text-xs text-muted-foreground">
            Developed by <span className="text-primary font-semibold">maruf</span>
          </p>
        </div>
      </div>
    </footer>
  )
}
